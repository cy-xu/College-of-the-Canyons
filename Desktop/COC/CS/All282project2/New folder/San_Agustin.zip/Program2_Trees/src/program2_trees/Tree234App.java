/* Marcello San Agustin
 * Computer Science 282
 * Project 2
 * 11/3/2015
 */
package program2_trees;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

class Tree234App {

    public static void main(String[] args) throws IOException {

        Tree234 theTree;
        long value;
        int numOfNodes;
        System.out.println("Enter the number of nodes for the tree: ");
        numOfNodes = getInt();

        Node.setOrder(numOfNodes);

        if (numOfNodes >= 5) {
            theTree = new BTree();
        } else {
            theTree = new Tree234();
        }

        theTree.insert(50);
        theTree.insert(40);
        theTree.insert(60);
        theTree.insert(30);
        theTree.insert(70);
        theTree.insert(80);
        theTree.insert(90);
        theTree.insert(100);
        theTree.insert(110);
        theTree.insert(120);
        theTree.insert(130);

        while (true) {

            System.out.print("Enter first letter of ");

            System.out.print("Show, Insert, Find, Change order, Read file or Quit: ");

            char choice = getChar();

            switch (choice) {

                case 's':

                    theTree.displayTree();

                    break;

                case 'i':

                    System.out.print("Enter value to insert: ");

                    value = getInt();

                    theTree.insert(value);

                    break;

                case 'f':

                    System.out.print("Enter value to find: ");

                    value = getInt();

                    int found = theTree.find(value);

                    if (found != -1) {
                        System.out.println("Found " + value);
                    } else {
                        System.out.println("Could not find " + value);
                    }

                    break;

                case 'q':

                    System.exit(0);
                    break;
                case 'c':

                    System.out.println("Enter number of children:");
                    int setNodes = getInt();
                    Node.setOrder(setNodes);
                    break;
                case 'r':
                    readRecord();

                default:

                    System.out.print("Invalid entry\n");

            }  // end switch

        }  // end while

    }  // end main()

//--------------------------------------------------------------
    public static String getString() throws IOException {

        InputStreamReader isr = new InputStreamReader(System.in);

        BufferedReader br = new BufferedReader(isr);

        String s = br.readLine();

        return s;

    }

//--------------------------------------------------------------
    public static char getChar() throws IOException {

        String s = getString();

        return s.charAt(0);

    }

//-------------------------------------------------------------
    public static int getInt() throws IOException {

        String s = getString();

        return Integer.parseInt(s);

    }

//-------------------------------------------------------------
    public static void readRecord() throws IOException {
        String recordName;
        String dataFromRecord;
        long idNumber;

        try {

            System.out.println("Enter the name of the record:");
            recordName = getString();
            File file = new File(recordName);
            FileReader fileRead = new FileReader(file);
            BufferedReader buffRead = new BufferedReader(fileRead);

            while (buffRead.readLine() != null) {
                dataFromRecord = buffRead.readLine();
                String[] lineFromRecord = dataFromRecord.split(",");
                System.out.println(lineFromRecord[0]);
                
            }
        } catch (IOException e) {
            System.out.println("Can't find it!!");
        }
    }

}  // end class Tree234App
