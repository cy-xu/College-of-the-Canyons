/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program2_trees;

/**
 *
 * @author MARCELLO
 */
public class BTree extends Tree234 {

    @Override
    public void split(Node thisNode) {

        int orderTemp = Node.ORDER;
        int counter = 0;

        while (orderTemp >= 5) {
            orderTemp /= 2;
            counter++;
        }

        DataItem[] items = new DataItem[counter + 1];

        for (int x = counter; x > 0; x--) {
            items[x] = thisNode.removeItem();
        }

        DataItem itemB;
        Node parent;
        Node[] children = new Node[counter];
        int itemIndex;

        itemB = thisNode.removeItem();    // this node

        //makes array of children to move
        int tempCount = 0;
        for (int i = counter; i > 0; i--) {
            children[tempCount] = thisNode.disconnectChild(Node.ORDER - i);
            tempCount++;
        }

        Node newRight = new Node();       // make new node

        if (thisNode == root) {
            root = new Node();                // make new root
            parent = root;
            root.connectChild(0, thisNode);   // connect to parent
        } else {
            parent = thisNode.getParent();    // get parent
        }
        // deal with parent
        itemIndex = parent.insertItem(itemB); // item B to parent
        int n = parent.getNumItems();         // total items?

        for (int j = n - 1; j > itemIndex; j--) { // move parent's connections one child to the right

            Node temp = parent.disconnectChild(j);
            parent.connectChild(j + 1, temp);
        }

        parent.connectChild(itemIndex + 1, newRight);

        for (int y = 0; y < counter + 1; y++) {
            if (items[y] == null) {
                continue;
            }

            newRight.insertItem(items[y]);

            //reconnect children to new parent
            for (int j = 0; j < counter; j++) {
                newRight.connectChild(j, children[j]);
            }
        }
    }
}

//    @Override
//    public void split(Node thisNode) // split the node
//    {
//      // assumes node is full
//        DataItem itemB, itemC;
//
//        Node parent, child2, child3;
//
//        int itemIndex;
//
//        itemC = thisNode.removeItem();    // remove items from
//
//        itemB = thisNode.removeItem();    // this node
//
//        child2 = thisNode.disconnectChild(2); // remove children
//
//        child3 = thisNode.disconnectChild(3); // from this node
//
//        Node newRight = new Node();       // make new node
//
//        if (thisNode == root) // if this is the root,
//        {
//
//            root = new Node();                // make new root
//
//            parent = root;                    // root is our parent
//
//            root.connectChild(0, thisNode);   // connect to parent
//
//        } else // this node not the root
//        {
//            parent = thisNode.getParent();    // get parent
//        }
//
//      // deal with parent
//        itemIndex = parent.insertItem(itemB); // item B to parent
//
//        int n = parent.getNumItems();         // total items?
//
//        for (int j = n - 1; j > itemIndex; j--) // move parent's
//        {                                      // connections
//
//            Node temp = parent.disconnectChild(j); // one child
//
//            parent.connectChild(j + 1, temp);        // to the right
//
//        }
//
//                                   // connect newRight to parent
//        parent.connectChild(itemIndex + 1, newRight);
//
//      // deal with newRight
//        newRight.insertItem(itemC);       // item C to newRight
//
//        newRight.connectChild(0, child2); // connect to 0 and 1
//
//        newRight.connectChild(1, child3); // on newRight
//
//    }  // end split()
//}
