/* Marcello San Agustin
 * Computer Science 282
 * Project 2
 * 11/3/2015
 */
package program2_trees;

// tree234.java
// demonstrates 234 tree
// to run this program: C>java Tree234App
//import java.io.*;
////////////////////////////////////////////////////////////////
class DataItem {

    public long dData;          // one data item
    public String record;
    

//--------------------------------------------------------------
    public DataItem(long dd) // constructor
    {
        dData = dd;
    }

//--------------------------------------------------------------
    public void displayItem() // display item, format "/27"
    {
        System.out.print("|" + dData);
    }

//--------------------------------------------------------------
    
    public DataItem(String rec){
        record = rec;
        
    }
    
}  // end class DataItem
 
////////////////////////////////////////////////////////////////
