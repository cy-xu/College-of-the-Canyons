import java.util.ArrayList;
import cs1.Keyboard;
public class Poker
{
    private Deck deck;
    private Hand hand;
    public Poker()
    {
        deck = new Deck();
        deck.shuffle();
        hand = new Hand();
        for (int i = 0 ; i < 5 ; i++)
        {
            hand.addCard(deck.dealCard());
        }
    }
    public int numMatches()
    {
        for (int i = 0; i < hand.getHandSize() ; i++)
        {
           // if (hand.getCard(i).getValue())
            {

            }
        }
        return 69;
    }
    
    public void game()
    {
        hand.sortValue();
        System.out.println("Your start with hand: "+ hand);
        System.out.println("Would you like to exchange any cards? [yes] or [no]");
        String exchangeYesNo = Keyboard.readString();
        if (exchangeYesNo.equals("yes"))
        {
            int removeCount = 0;
            for (int i = 0 ; i < hand.getHandSize() ; i++)
            {
                System.out.println("Exchange "+ hand.getCard(i) + "? [yes] or [no]");
                String x = Keyboard.readString();
                if (x.equals("yes"))
                {
                    hand.removeCard(i);
                    removeCount++;
                    i--;
                }
                /*else if(x.equals("no"))
                {
                    
                }*/
            }
            System.out.println("Remaining hand is: " + hand);
            System.out.println("You draw "+removeCount+" cards");
            for (int j = 0; j < removeCount ; j++)
            {
                hand.addCard(deck.dealCard());
                
            }
            System.out.println("Hand: " + hand);
        }
        else
        {
            System.out.println("You keep hand: "+ hand);
        }

            
            /*else if (exchangeYesNo.equals("no"))
            {
                
            }*/
            /*else
            {
                System.out.println("Please enter a valid answer");
            }*/
        /*while (true)
        {
            System.out.println("How many cards to exchange?");
            int cardExchange = Keyboard.readInt();
            if (cardExchange > 5 || cardExchange < 0)
            {
                System.out.println("Please enter valid number to exchange");
            }
            else
            {
                break;
            }
        }*/
    }
    public static void main(String[] args)
    {
        Poker play = new Poker();
        play.game();
    }
    /*
     Royal flush
     straight flush 
     fourofakind
     full house
     flush
     straight
     three of a kind
     2 pair
     one pair
     
     */
}
