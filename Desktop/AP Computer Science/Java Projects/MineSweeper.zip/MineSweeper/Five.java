import info.gridworld.actor.*;
import info.gridworld.grid.*;

import java.awt.Color;
import java.util.ArrayList;

public class Five extends Actor
{
    public Five()
    {
        
    }
    
}
