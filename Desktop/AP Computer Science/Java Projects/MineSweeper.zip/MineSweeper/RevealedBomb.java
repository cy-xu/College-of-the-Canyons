import info.gridworld.actor.*;
import info.gridworld.grid.*;

import java.awt.Color;
import java.util.ArrayList;
public class RevealedBomb extends Actor
{
    public RevealedBomb()
    {
        
    }
}